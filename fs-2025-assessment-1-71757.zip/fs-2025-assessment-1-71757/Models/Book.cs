﻿namespace fs_2025_assessment_1_71757.Models
{
    public class Book
    {
    }
}
