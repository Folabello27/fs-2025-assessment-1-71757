﻿using fs_2025_assessment_1_71757.Data;

namespace fs_2025_assessment_1_71757.Startup
{
    public static class DependenciesConfig
    {
        public static void AddDependencies(this WebApplicationBuilder builder)
        {
            builder.Services.AddTransient<CourseData>();
            builder.Services.AddMemoryCache();
        }
    }
}
