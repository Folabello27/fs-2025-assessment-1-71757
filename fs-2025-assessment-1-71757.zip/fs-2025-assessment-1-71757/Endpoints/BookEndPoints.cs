﻿namespace fs_2025_assessment_1_71757.Endpoints
{
    public static class BookEndPoints
    {
        public static void AddBookEndPoints(this WebApplication app)
        {

        }
    }
}
