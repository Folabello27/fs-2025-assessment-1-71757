﻿namespace fs_2025_assessment_1_71757.Endpoints
{
    public static class RootEndPoints
    {
        public static void AddRootEndPoints(this WebApplication app)
        {

        }
    }
}
